package edu.usna.whatsappusna;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class PollsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_polls);
        WebView webView = (WebView) findViewById(R.id.polls_webview);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webView.loadUrl("https://docs.google.com/forms/d/e/1FAIpQLScOKsYde7X5RppRjnI6AkqWZuR5MomoxWfmcQxLhszDEjQg4A/viewform?usp=sf_link");
    }
}