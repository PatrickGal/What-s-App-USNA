package edu.usna.whatsappusna;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button_nabsd = (Button) findViewById(R.id.button_nabsd);
        Button button_polls = (Button) findViewById(R.id.button_polls);
        Button button_mwf = (Button) findViewById(R.id.button_mwf);
        Button button_contacts = (Button) findViewById(R.id.button_contacts);
        Button button_pod = (Button) findViewById(R.id.button_pod);
        Button button_menus = (Button) findViewById(R.id.button_menus);
        Button button_weather = (Button) findViewById(R.id.button_weather);
        Button button_sports = (Button) findViewById(R.id.button_sports);
        Button button_regs = (Button) findViewById(R.id.button_regulations);
        Button button_feedback = (Button) findViewById(R.id.button_feedback);

        button_nabsd.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), NabsdActivity.class);
            startActivity(intent);
        });

        button_polls.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), PollsActivity.class);
            startActivity(intent);
        });

        button_mwf.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), MwfActivity.class);
            startActivity(intent);
        });

        button_contacts.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), ContactsActivity.class);
            startActivity(intent);
        });

        button_pod.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), PodActivity.class);
            startActivity(intent);
        });

        button_menus.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), MenusActivity.class);
            startActivity(intent);
        });

        button_weather.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), WeatherActivity.class);
            startActivity(intent);
        });

        button_sports.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), SportsActivity.class);
            startActivity(intent);
        });

        button_regs.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), RegsActivity.class);
            startActivity(intent);
        });

        button_feedback.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), FeedbackActivity.class);
            startActivity(intent);
        });
    }
}