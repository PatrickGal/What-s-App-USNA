package edu.usna.whatsappusna;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class FeedbackActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        WebView webView = (WebView) findViewById(R.id.feedback_webview);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webView.loadUrl("https://docs.google.com/forms/d/e/1FAIpQLSdglHgMAAVY07vYINzcTPLeqLw8KBMgFLEdA8y12rTOQ2Ljiw/viewform?usp=sf_link");
    }
}