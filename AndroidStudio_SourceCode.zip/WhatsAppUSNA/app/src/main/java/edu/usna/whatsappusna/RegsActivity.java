package edu.usna.whatsappusna;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class RegsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regs);

        Button button_midregs = (Button) findViewById(R.id.regs_button_midregs);
        Button button_uniform = (Button) findViewById(R.id.regs_button_uniform);

        button_midregs.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), MidregsActivity.class);
            startActivity(intent);
        });

        button_uniform.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), UniformActivity.class);
            startActivity(intent);
        });
    }
}