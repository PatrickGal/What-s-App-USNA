package edu.usna.whatsappusna;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MidregsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_midregs);
        WebView webView = (WebView) findViewById(R.id.midregs_webview);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webView.loadUrl("https://docs.google.com/gview?embedded=true&url=https://www.usna.edu/Commandant/Directives/Instructions/1000-1999/COMDTMIDNINST-1020.3C_MIDSHIPMEN-UNIFORM-REGULATIONS.pdf#search=Uniform%20regs");
    }
}